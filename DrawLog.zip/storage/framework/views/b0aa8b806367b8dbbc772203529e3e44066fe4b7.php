<form method="POST" action="/categorias-admin/<?php echo e($id); ?>">
	<?php echo method_field('DELETE'); ?>
	<?php echo csrf_field(); ?>
	<a href="/categorias-admin/<?php echo e($id); ?>"><button class="button is-danger is-outlined"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
</form> <?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/IntAdmin/intCategorias/botones/delete.blade.php ENDPATH**/ ?>