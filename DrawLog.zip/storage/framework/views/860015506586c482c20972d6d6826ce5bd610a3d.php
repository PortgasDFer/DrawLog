

<?php $__env->startSection('content'); ?>
<section class="section">
<div class="columns is-marginless is-centered is-desktop ">
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column is-2 is-mobile-is-full">
            <a href="/draws/<?php echo e($c->name); ?>/view"><button class="button is-rounded" style="background-color:<?php echo e($c->color); ?>; color:white;"><?php echo e($c->name); ?></button></a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</section>
<section class="section">
    <div class="columns">
        <div class="column">
            <section class="section background-hero">
              <h1 class="title">Bienvenido a DrawLog</h1>
              <h2 class="subtitle has-text-white is-size-3">
                La comunidad más grande de artistas de habla hispana.
              </h2>
            </section>
        </div>
    </div>
    <h3 class="is-size-3">Trabajos recomendados</h3>
    <div class="columns is-multiline is-mobile has-text-centered">
        <!-- section1 -->
        <?php $__currentLoopData = $draws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="column is-3-desktop is-6-tablet is-12-mobile">
              <div class="card">
                <div class="card-image">
                  <a href="/draw/<?php echo e($draw->slug); ?>/view">
                 
                      <img src="draws/<?php echo e($draw->art); ?>" alt="Placeholder image">
         
                  </a>
                </div>
              </div>
              <p class="is-size-4"><a href="/draw/<?php echo e($draw->slug); ?>/view"><?php echo e($draw->name_draw); ?></a></p>
              <p class="is-size-6">By: <a href="/user/<?php echo e($draw->slug_user); ?>/profile"><?php echo e($draw->name); ?></a></p>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- section2 -->
    </div>
</section>
<section class="section">
    <h3 class="is-size-3 ">Ranking diario <i class="fa fa-star" aria-hidden="true"></i></h3>
    <div class="columns is-multiline is-mobile has-text-centered">
        <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column is-2-desktop is-4-tablet is-12-mobile">
            <div class="card">
              <div class="card-image">
                <figure class="image is-1 by 1">
                  <img src="draws/<?php echo e($rank->art); ?>" alt="Placeholder image">
                </figure>
              </div>
            </div>
            <p class="is-size-4"><a href="/draw/<?php echo e($rank->slug); ?>/view"><?php echo e($rank->name_draw); ?></a></p>
            <p class="is-size-6">By: <a href="/user/<?php echo e($rank->slug_user); ?>/profile"><?php echo e($rank->name); ?></a></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="columns is-multiline is-mobile has-text-centered">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/welcome.blade.php ENDPATH**/ ?>