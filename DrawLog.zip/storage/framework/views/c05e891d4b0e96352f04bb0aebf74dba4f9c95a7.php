<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'DrawLog')); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    
    <title>DrawLog - Bienvenido</title>
</head>
<body>

<?php if(Auth::user()->hasRole('admin')): ?>
  <?php echo $__env->make('IntAdmin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(Auth::user()->hasRole('user')): ?>
  <?php echo $__env->make('IntUsers.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<section class="section">
  <?php echo $__env->yieldContent('content'); ?>
</section>
<footer class="footer">
  <div class="content has-text-centered">
    <p>
      <strong>DrawLog</strong> by <a href="#">Fernando López Servín</a>.
    </p>
  </div>
</footer>
<!-- Scripts -->

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
<script src = "http://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js" defer ></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/layouts/template.blade.php ENDPATH**/ ?>