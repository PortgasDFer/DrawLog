

<?php $__env->startSection('content'); ?>
<section class="hero is-link pt-4">
  <div class="hero-body">
    <p class="title">
      ¡Conviertete en un artista!
    </p>
    <p class="subtitle">
      Edita  tu ilustración
    </p>
  </div>
</section>
<section class="section">
	<div class="container">
		<?php if(count($errors) > 0): ?>
			<div class="notification is-danger">
			  <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
			</div>
    <?php endif; ?>
		<div class="columns is-multiline is-mobile has-text-centered">
			<div class="column is-4-desktop is-6-tablet is-12-mobile">
				<label class="label">Imagen a editar</label>
					<figure class="image is-4by5">
	  			<img src="/draws/<?php echo e($draw->art); ?>">
					</figure>
			</div>
			<div class="column is-8-desktop is-6-tablet is-12-mobile">
				<form class="box is-primary" action="/misIlustraciones/<?php echo e($draw->slug); ?>" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
			<div class="field">	
				<label class="label">Ilustración</label>
				<div id="file-js-example" class="file has-name">
          <label class="file-label">
            <input class="file-input" type="file" name="dibujo">
            <span class="file-cta">
              <span class="file-icon">
                <i class="fa fa-upload" aria-hidden="true"></i>
              </span>
              <span class="file-label">
                Escoge un archivo…
              </span>
            </span>
            <span class="file-name">
              No se ha seleccionado
            </span>
          </label>
        </div>
			</div>	
		  <div class="field">
		    <label class="label">Nombre</label>
		    <div class="control">
		      <input class="input" type="text" placeholder="Ej: Arte digital" name="nombre" value="<?php echo e($draw->name_draw); ?>">
		    </div>
		  </div>
		  <div class="field">
		    <label class="label">Precio</label>
		    <div class="control">
		      <input class="input" type="text" placeholder="Arte generado por computadora" name="precio" value="<?php echo e($draw->precio); ?>">
		    </div>
		  </div>
		  <div class="field">
		    <label class="label">Categoría</label>
		    <div class="control">
		      <div class="select">
				  <select class="input" name="categoria">
				  		<option value="<?php echo e($draw->id_categoria); ?>">Conservar misma categoría</option>
				    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
				  </select>
				</div>
		    </div>
		  </div>
		  <div class="field">	
		  	<label class="label">NSFW</label>
		  	<div class="field">
			  <input id="switchColorDefault" type="checkbox" name="nsfw" class="switch" checked="checked">
			  <label for="switchColorDefault">Si</label>
			</div>
		  </div>	
		  <div class="field">	
		  		<label class="label">Descripción</label>
		  		<textarea class="textarea is-primary" placeholder="Primary textarea" name="descripcion"><?php echo e($draw->descripcion); ?></textarea>
		  </div>		
		  <div class="field">
		  	<label class="label">Etiquetas</label>
		  	<input class="input" type="tags" placeholder="Add Tag" value="<?php $__currentLoopData = $draw->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($tag->name); ?>,  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
		  </div>
		  <button type="submit" class="button is-primary">Registrar</button>
		</form>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bulma-tagsinput@2.0.0/dist/js/bulma-tagsinput.min.js"></script>
<script>	
const fileInput = document.querySelector('#file-js-example input[type=file]');
  fileInput.onchange = () => {
    if (fileInput.files.length > 0) {
      const fileName = document.querySelector('#file-js-example .file-name');
      fileName.textContent = fileInput.files[0].name;
    }
}
bulmaTagsinput.attach();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/IntUsers/ilustraciones/edit.blade.php ENDPATH**/ ?>