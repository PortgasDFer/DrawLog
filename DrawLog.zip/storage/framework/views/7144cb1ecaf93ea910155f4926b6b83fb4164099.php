

<?php $__env->startSection('content'); ?>
<section class="section">
	<nav class="breadcrumb has-succeeds-separator" aria-label="breadcrumbs">
	  <ul>
	    <li><a href="/home">Inicio</a></li>
	    <li><a href="/tag/<?php echo e($tag->slug); ?>/view">Busqueda por etiqueta #<?php echo e($tag->name); ?></a></li>
	  </ul>
	</nav>
	<h2 class="is-size-4">Destacados:</h2>
	 <div class="columns is-multiline is-mobile has-text-centered">
        <!-- section1 -->
        <?php $__empty_1 = true; $__currentLoopData = $draws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="column is-3-desktop is-6-tablet is-12-mobile">
          <a href="/draw/<?php echo e($draw->slug); ?>/view">
            <div class="card">
              <div class="card-image">
                  <img src="/draws/<?php echo e($draw->art); ?>" alt="<?php echo e($draw->name_draw); ?>">
              </div>
            </div>
          </a>
            <p class="is-size-4"><a href="/draw/<?php echo e($draw->slug); ?>/view"><?php echo e($draw->name_draw); ?></a></p>
            <p class="is-size-6">By: <a href="/user/<?php echo e($draw->slug_user); ?>/profile"><?php echo e($draw->name); ?></a></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <section class="section">
        <div class="container">
          <h1 class="title">Ooops!</h1>
          <h2 class="subtitle">
            No se encontraron resultados, <a href="/misIlustraciones/create">¡Carga una ilustración!</a>
          </h2>
        </div>
      </section>
      <?php endif; ?>
  </div>
</section>
<section class="section">
	<h3 class="is-size-4">Otros resultados</h3>
	<div class="columns is-multiline is-mobile has-text-centered">
		 <?php $__currentLoopData = $anothers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="column is-3-tablet is-6-mobile">
        <img src="/draws/<?php echo e($d->art); ?>" alt="<?php echo e($d->name_draw); ?>">
        <p class="is-size-4"><a href="/draw/<?php echo e($d->slug); ?>/view"><?php echo e($d->name_draw); ?></a></p>
            <p class="is-size-6">By: <a href="/user/<?php echo e($d->slug_user); ?>/profile"><?php echo e($d->name); ?></a></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/IntUsers/ilustraciones/busquedaEtiqueta.blade.php ENDPATH**/ ?>