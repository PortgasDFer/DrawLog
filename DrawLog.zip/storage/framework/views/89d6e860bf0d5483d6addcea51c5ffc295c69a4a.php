
<?php $__env->startSection('content'); ?>
<section class="hero is-link pt-4">
  <div class="hero-body">
    <p class="title">
      Edita la categoría <?php echo e($categoria->name); ?>

    </p>
    <p class="subtitle">
      <?php echo e($categoria->description); ?>.
    </p>
  </div>
</section>
<section class="section">
	<div class="container">
		<form class="box is-primary" action="/categorias-admin/<?php echo e($categoria->id); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>
		  <div class="field">
		    <label class="label">Nombre</label>
		    <div class="control">
		      <input class="input" type="text" placeholder="Ej: Arte digital" name="nombre" value="<?php echo e($categoria->name); ?>">
		    </div>
		  </div>

		  <div class="field">
		    <label class="label">Descripción</label>
		    <div class="control">
		      <input class="input" type="text" placeholder="Arte generado por computadora" name="descripcion" value="<?php echo e($categoria->description); ?>">
		    </div>
		  </div>
		  
		  <div class="field">
		  	<label class="label">Color de etiqueta</label>
		  	<div class="control"> 
		  		<input type="color" id="colorpicker" value="<?php echo e($categoria->color); ?>" name="color">
		  	</div>
		  </div>	

		  <button type="submit" class="button is-primary">Registrar</button>
		</form>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/IntAdmin/intCategorias/edit.blade.php ENDPATH**/ ?>