

<?php $__env->startSection('content'); ?>
<section class="section">	
	<div class="container">
		<div class="columns is-multiline is-mobile has-text-centered">
			<div class="column is-6-desktop is-7-tablet is-12-mobile">
				<?php if($draw->estado=="Reportada"): ?>
				<div class="notification is-danger is-light">
				  <button class="delete"></button>
				  Esta ilustración ha sido reportada. <strong>Nuestros administradores revisaran el motivo y se tomará una desición al respecto del reporte.</strong>
				</div>
				<?php endif; ?>
				<div class="card">
				  <div class="card-image">
				    
				      <img src="/draws/<?php echo e($draw->art); ?>" alt="Placeholder image">
				    
				  </div>
				  <div class="card-content">
				    <div class="media">
				      <div class="media-left">
				        <figure class="image is-48x48">
				          <img src="/avatars/<?php echo e($profile->avatar); ?>" alt="Placeholder image">
				        </figure>
				      </div>
				      <div class="media-content">
				        <p class="title is-4"><?php echo e($draw->name_draw); ?></p>
				        <p class="subtitle is-6"><a href="/user/<?php echo e($autor->slug); ?>/profile"><?php echo e($autor->name); ?></a></p>
				        <p class="subtitle is-6">Likes: ♥ <?php echo e($draw->likes); ?> </p>
				      </div>
				    </div>

				    <div class="content">
				      <?php echo e($draw->descripcion); ?>

				      <?php $__currentLoopData = $draw->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="/tag/<?php echo e($tag->slug); ?>/view">#<?php echo e($tag->name); ?></a>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      <br>
				      <time datetime="2016-1-1"><?php echo e($draw->created_at->format('H:i')); ?> - <?php echo e($draw->created_at->format('d/m/Y')); ?></time>
				    </div>
				  </div>
				</div>
				<div class="section">
					<div class="buttons is-pulled-left">
						<button class="button is-info is-outlined"  id="Btn-report" onclick="mostrar()"> <i class="fa fa-flag-checkered" aria-hidden="true"></i>Report</button>	
					</div>	
					<div class="buttons is-pulled-right">
						<form action="/follow/<?php echo e($draw->slug); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<button class="button is-link is-outlined" type="submit"> <i class="fa fa-user-plus" aria-hidden="true"></i>Follow</button>
						</form>
						<form action="/like/<?php echo e($draw->slug); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<button class="button is-danger is-outlined" type="submit"> <i class="fa fa-heart-o" aria-hidden="true"></i>Like</button>
						</form>
					</div>	
				</div>
				<div class="section escondete" id="contenedor-reporte">
				<h3 class="is-size-3">Motivos del reporte</h3>	
					<article class="media">
					  <div class="media-content is-12">
					  	<form action="/reportar/<?php echo e($draw->slug); ?>" method="POST">
					  		<?php echo csrf_field(); ?> 
					  		<div class="field">
						      <p class="control">
						        <textarea class="textarea" placeholder="Add a comment..." name="reporte" required=""></textarea>
						        <input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id); ?>">
						      </p>
						    </div>
						    <div class="field">
						      <p class="control">
						        <button class="button is-dark" type="submit">Enviar reporte</button>
						      </p>
						    </div>
					  	</form>
					  </div>
					</article>
				</div>
			</div>	
			<div class="column is-6-desktop is-5-tablet is-12-mobile">
				<p class="is-size-3">Comentarios</p>
				<?php $__empty_1 = true; $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<article class="media">
				  <figure class="media-left">
				    <p class="image is-64x64">
				      <img src="/avatars/<?php echo e($coment->avatar); ?>">
				    </p>
				  </figure>
				  <div class="media-content">
				    <div class="content">
				      <p>
				        <strong><?php echo e($coment->name); ?></strong>
				        <br>
				        <?php echo e($coment->comentario); ?>

				        <br>
				      </p>
				    </div>
				  </div>
				</article>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<h2>¡Se el primero en comentar!</h2>
				<?php endif; ?>
				
				<article class="media">
				  <figure class="media-left">
				    <p class="image is-64x64">
				      <img src="/avatars/<?php echo e($visitante->avatar); ?>">
				    </p>
				  </figure>
				  <div class="media-content">
				  	<form action="/comentario/<?php echo e($draw->slug); ?>" method="POST">
				  		<?php echo csrf_field(); ?> 
				  		<div class="field">
					      <p class="control">
					        <textarea class="textarea" placeholder="Add a comment..." name="comentario" required=""></textarea>
					        <input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id); ?>">
					      </p>
					    </div>
					    <div class="field">
					      <p class="control">
					        <button class="button is-dark" type="submit">Publicar comentario</button>
					      </p>
					    </div>
				  	</form>
				  </div>
				</article>	
			</div>
		</div>
	</div>
</section>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>	
	let caja_reporte= document.getElementById('contenedor-reporte');
	function mostrar(){
		console.log(caja_reporte.classList);
		caja_reporte.classList.remove('escondete');
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/IntUsers/ilustraciones/lonely.blade.php ENDPATH**/ ?>