

<?php $__env->startSection('content'); ?>
 <div class='columns'>
  <div class='container profile'>
    <div class='section profile-heading'>
      <div class='columns is-mobile is-multiline'>
        <div class='column is-2'>
          <span class='header-icon user-profile-image'>
            <img alt='' src='/avatars/<?php echo e($profile->avatar); ?>'>
          </span>
        </div>
        <div class='column is-4-tablet is-10-mobile name'>
          <p>
            <span class='title is-bold'><?php echo e($user->name); ?></span>
            <br>

            <form action="/follow-profile/<?php echo e($user->slug_user); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button class="button is-link is-outlined" type="submit"> <i class="fa fa-user-plus" aria-hidden="true"></i>Follow</button>
            </form>
            <br>
          </p>
          <p class='tagline'>
            <?php echo e($profile->nombre); ?> <?php echo e($profile->apellidos); ?> <br> 
            <?php echo e($profile->pais); ?> <br> 
            <a href="<?php echo e($profile->fb); ?>"><i class="fa fa-facebook-square" aria-hidden="true"></i></a> 
            <a href="<?php echo e($profile->tw); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href="<?php echo e($profile->ig); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a>
          </p>
        </div>
        <div class='column is-2-tablet is-4-mobile has-text-centered'>
          <p class='stat-val'><?php echo e($profile->visitas); ?></p>
          <p class='stat-key'>Visitas</p>
        </div>
        <div class='column is-2-tablet is-4-mobile has-text-centered'>
          <p class='stat-val'><?php echo e($profile->seguidores); ?></p>
          <p class='stat-key'>Seguidores</p>
        </div>
        <div class='column is-2-tablet is-4-mobile has-text-centered'>
          <p class='stat-val'><?php echo e($noIlustraciones); ?></p>
          <p class='stat-key'>Ilustraciones</p>
        </div>
      </div>
    </div>
    <div class='profile-options is-fullwidth'>
      <div class='tabs is-fullwidth is-medium'>
        <ul>
          <li class='link'>
            <a>
              <span class='icon'>
                <i class='fa fa-list'></i>
              </span>
              <span>Sus ilustraciones</span>
            </a>
          </li>
          <li class='link is-active'>
            <a>
              <span class='icon'>
                <i class='fa fa-thumbs-up'></i>
              </span>
              <span>Siguiendo</span>
            </a>
          </li>
          <li class='link'>
            <a>
              <span class='icon'>
                <i class='fa fa-search'></i>
              </span>
              <span>Seguidores</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class='box' style='border-radius: 0px;'>
      <!-- Main container -->
      <div class='columns'>
        <div class='column is-2-tablet user-property-count has-text-centered'>
          <p class='subtitle is-5'>
            <strong></strong>
            <?php echo e($noIlustraciones); ?>

            <br>
            Ilustraciones
          </p>
        </div>
        <div class='column is-8'>
          <p class='control has-addons'>
            <input class='input' placeholder='Search your liked properties' style='width: 100% !important' type='text'>
            <button class='button'>
              Buscar
            </button>
          </p>
        </div>
      </div>
    </div>
    <div class='columns is-mobile'>
      <?php $__empty_1 = true; $__currentLoopData = $ilustraciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class='column is-3-tablet is-6-mobile'>
        <div class='card'>
          <a href="/draw/<?php echo e($draw->slug); ?>/view">
            <div class='card-image'>
              <figure class='image is-4by3'>
                <img alt='' src='/draws/<?php echo e($draw->art); ?>'>
              </figure>
            </div>
          </a>
          <div class='card-content'>
            <div class='content'>
              <span class='tag is-dark subtitle'><?php echo e($draw->name_draw); ?></span>
              <p><?php echo e($draw->descripcion); ?></p>
            </div>
          </div>
          <footer class='card-footer'>
              <form method="POST" action="#" class="card-footer-item">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button class="button is-info is-outlined"> <i class="fa fa-flag-checkered" aria-hidden="true"></i>Report</button>  
              </form>
              <form method="POST" action="#" class="card-footer-item">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button class="button is-danger is-outlined"> <i class="fa fa-heart-o" aria-hidden="true"></i>Ver</button>
              </form>
          </footer>
        </div>
        <br>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2>No ha subido ilustraciones todavía.</h2>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
<script>
	$(() => {
	  $('#edit-preferences').click(function(){
	   $('#edit-preferences-modal').addClass('is-active');
	  });
	  $('.modal-card-head button.delete, .modal-save, .modal-cancel').click(function(){
	    $('#edit-preferences-modal').removeClass('is-active');
	  });
	});

  const fileInput = document.querySelector('#file-js-example input[type=file]');
  fileInput.onchange = () => {
    if (fileInput.files.length > 0) {
      const fileName = document.querySelector('#file-js-example .file-name');
      fileName.textContent = fileInput.files[0].name;
    }
  }
</script>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fernando\Desktop\DrawLog\resources\views/IntUsers/perfil/profile.blade.php ENDPATH**/ ?>